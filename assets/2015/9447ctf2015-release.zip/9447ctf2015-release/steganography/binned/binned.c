#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>        
#include <sys/socket.h>
#include <sys/fsuid.h>
#include <sys/sysinfo.h>
#include <netinet/in.h>
#include <sys/syscall.h>
#include <sys/klog.h>
#include <sys/times.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

struct linux_dirent {
	long           d_ino;
	off_t          d_off;
	unsigned short d_reclen;
	char           d_name[];
};

int func(int i) {
	int a = i & -i;
	return !a;
}

int checks(int a) {
	a *= 7;
	a -= 60;
	a %= 13;
	return ~a;
}

int ssss(int v) {
	if (checks(v)) {
		shmdt(&v);
	} else {
		umask(v);
	}
}

int main() {
	int fd = socket(AF_INET, SOCK_STREAM, 0);
	printf("Begin working out flag...\n");
	int pid, res;
	asm("syscall;":"=A"(pid):"a"(57));
	struct sockaddr_in addr;
	int len = sizeof(addr);
	res = getpeername(fd, &addr, &len);
	if (res == -1) {
		res = getpeername(fd, &addr, &len);
		if (res == -1) {
			int erno;
			len = sizeof(erno);
			res = getsockopt(fd, SOL_SOCKET, SO_ERROR, &erno, &len);
			asm("syscall;":"=A"(res):"a"(123));
			if (res == -1) {
				setfsuid(0);
			}
		} else {
			setfsuid(0);	
		}
	} else {
		setfsuid(0);
	}
	ssss(res);
	int gid = getgid();
	int euid = -1;
	int i;
	for (i = 0; i < gid; i++) {
		if (!i) {
			res = getsockname(fd, &addr, &len);	
		} else {
			if (i - 1) {
				res = setuid(euid);
			} else {
				euid = geteuid();
				res = -1;
			}
		}
		if (res == -1) {
			ssss(gid - 1);
			shutdown(fd, SHUT_WR);
		} else {
			int port = addr.sin_port;
			struct sysinfo si;
			sysinfo(&si);
			gid = port + 2;
		}
	}
	res = setresuid(euid, euid, euid);
	char buf[101];
	if (pid == 0) {
		for (i = 1; i; i++) {
			if (func(i)) {
				sprintf(buf, "%d", i);
				mkdir(buf, 0777);	
			}
		}
		return 0;
	} else {
		res = rmdir("10");
	}
	ssss(-res);
	ftruncate(fd, 1000);
	int pgid = getpgid(pid);
	for (i = 1; i < pgid; i++) {
		if (i & 1) {
			ssss(i);
		} else if (i == 4) {
			len = sizeof(addr);
			res = getpeername(fd, &addr, &len);
			if (res == -1) {
				addr.sin_port = htons(8888);
				inet_pton(AF_INET, "8.8.8.8", &addr.sin_addr);
				memset(addr.sin_zero, 0, 8);
				bind(fd, &addr, &len);
			}
			i++;
		} else if (i > 4) {
			addr.sin_port = htons(8888);
			inet_pton(AF_INET, "8.8.8.8", &addr.sin_addr);
			memset(addr.sin_zero, 0, 8);
			bind(fd, &addr, &len);
			pgid = setuid(pgid);
		} else {
			if (i < 3) {
				memset(addr.sin_zero, 0, 8);
			} else {
				chmod("10", 0777);
			}
		}
	}
	struct linux_dirent dir;
	int size = 0;
	res = syscall(SYS_getdents, fd, &dir, 1);
	if (res == -1) {
		size = 100;
		res = klogctl(2, buf, size); 
	}
	for (i = 0; i < size; i++) {
		if (i) {
			ssss(i);
			if (i % 2 == 0) {
				size = shutdown(fd, SHUT_RDWR);
			} else if (i % 3 == 0) {
				ssss(i);
			}
		} else {
			size /= 2;
		}
	}
	struct tms tms;
	res = times(&tms);
	res = msgsnd(1, &tms, sizeof(tms), IPC_NOWAIT);
	if (res == -1) {
		syscall(SYS_capget, 0, 0);
	}
	printf("Flag worked out!\n");
	return 0;
}
