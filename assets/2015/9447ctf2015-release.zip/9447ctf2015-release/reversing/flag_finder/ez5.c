#include <stdio.h>
#include <string.h>
#include "rand.h"
#include "enc.h"

int main(int argc, char *argv[]) {
	if (argc != 2) {
		printf("Usage: %s <password>\n", argv[0]);
		return 1;
	}
	int i;
	char flag[len];
	strcpy(flag, enc);
//	printf("%s\n", flag);
	int j = 0;
	for (i = 0; ; i++) {
		if (!memcmp(flag, "9447", 4)) {
			if (!memcmp(flag, argv[1], len)) {
				printf("The flag is %s\n", argv[1]);
			} else {
				printf("Try again\n");
			}
			break;
			if (j++ > 4) break;
		}
		flag[i % len] ^= rand_char();
//		printf("%u\n", r);
	}

	return 0;
}
