#!/bin/bash

for i in {1000000..1009000}; do rm gen; make CFLAGS="-DN_ITERATIONS=$i" && echo -e "break *400729\nr sdf\nx/s 0x00007FFFFFFFD8B0" | gdb ez5 ; done
