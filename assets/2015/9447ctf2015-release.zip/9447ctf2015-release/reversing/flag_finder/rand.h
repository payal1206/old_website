#define SEED 5489
// https://en.wikipedia.org/wiki/Linear_congruential_generator#Parameters_in_common_use
// m is 2^32, so just let it overflow with unsigned ints
unsigned int a = 1664525;
unsigned int c = 1013904223;
unsigned int r_val = SEED;

unsigned char rand_char() {
	r_val = a * r_val + c;
	return (r_val & 0xff00) / 0x100;
}
