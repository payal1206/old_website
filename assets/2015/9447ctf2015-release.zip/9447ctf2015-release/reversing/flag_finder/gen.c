#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "rand.h"

// TODO pick a number of iterations that menas that we aren't fucked
#ifndef N_ITERATIONS
// #define N_ITERATIONS (sizeof(flag) * 1 + 1)
#define N_ITERATIONS 1000024
#endif

int main(int argc, char *argv[]) {
	freopen("enc.h", "w", stdout);
	int i;
	char flag[] = "9447{C0ngr47ulaT1ons_p4l_buddy_y0Uv3_solved_the_re4l__H4LT1N6_prObL3M}";
	int len = strlen(flag);
	char enc[sizeof(flag)];
	strcpy(enc, flag);
	for (i = 0; i < N_ITERATIONS; i++) {
		enc[i % len] ^= rand_char();
		if (!memcmp(enc, "9447", 4)) {
			fprintf(stderr, "'9447' prefix prematurely encountered at ind %d\n", i);
			return 1;
		}
	}
	printf("unsigned int len = %d;\n", len);
	printf("char enc[] = \"");
	int j;
	for (j = 0; j < len; j++) {
		printf("\\x%02x", (unsigned char)enc[j]);
	}
	printf("\";\n//");
	for (j = 0; j < len; j++) {
		if (isprint(enc[j])) {
			printf("%c", enc[j]);
		} else {
			printf("\\u00%02x", (unsigned char)enc[j]);
		}
	}
	printf("\n");


	r_val = SEED;
	for (i = 0; i < N_ITERATIONS; i++) {
		enc[i % len] ^= rand_char();
		if (i != N_ITERATIONS - 1 && !memcmp(enc, "9447", 4) && memcmp(enc, flag, len)) {
			fprintf(stderr, "'9447' prefix prematurely encountered at ind %d on backtrack\n", i);
			fprintf(stderr, "%s\n", enc);
			fprintf(stderr, "%lu\n", (unsigned long int)N_ITERATIONS);
			return 1;
		}
	}

	fprintf(stderr, "DONE\n\n\n\n\n\n\n\n\n%lu\n\n\n\n\n\n\n\n\n\n", (unsigned long int)N_ITERATIONS);
	return 0;
}
