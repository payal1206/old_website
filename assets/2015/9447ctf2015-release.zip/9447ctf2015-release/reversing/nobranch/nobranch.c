#include <stdio.h>

#define INLINE		__attribute__((always_inline)) inline static

INLINE unsigned char swap(unsigned char c) {
	return c ^ ((((((signed char) 0x40) << 2) >> 2) & c) >> 1);
}

INLINE unsigned char next(unsigned char c) {
	c = (c + 1) + (((c & 0x1F) + 6) >> 5) * 6 - ((((c / 19) * (c / 20) ^ 0x39) + 1) >> 6) * 0xf + ((unsigned char) (c - 0x30) >> 7) * 0x11;
	c -= (c >> 7) * 0x51;
	c -= (((c ^ 0x40) + 3) >> 7) * 0xe;
	return c;
}

INLINE unsigned char rot13(unsigned char c) {
	return (c + (13 * ((c & 0x40) >> 6))) - (((((c + 2) & 0x50) >> 4) + 3) >> 3) * 26;
}

INLINE unsigned char tob64(unsigned char c) {
	c += ((c / 2) + 1) >> 5;
	c = ((c / 13) >> 1) * 6 + (65 + c);
	c += -(c >> 7) * (65 + (c / 70) * 16 - (((c / 47) + 1) >> 2) * 3);
	return c;
}

INLINE unsigned char fromb64(unsigned char c) {
	c -= 59;
	c -= 6 * (c / 32 + 1);
	c -= 20 * ((c + 1) / 99);
	c -= (c >> 7) * 105;
	c -= (c >> 6) * 5;
	c -= (c >> 6) * 3;
	return c;	
}

// Assumes both are b64 encoded.
INLINE unsigned char xor(unsigned char c1, unsigned char c2) {
	return tob64(fromb64(c1) ^ fromb64(c2));
}

// Assumes in is 3 bytes long, out is 4 bytes long, and place in normally.
INLINE void convBit(unsigned char* in, unsigned char* out) {
	out[3] = tob64(in[2] & 0x3f);
	out[2] = tob64((in[2] >> 6) | ((in[1] & 0xf) << 2));
	out[1] = tob64((in[1] >> 4) | ((in[0] & 0x3) << 4));
	out[0] = tob64(in[0] >> 2);
}

// Assumes in is 3 bytes long, out is 4 bytes long, and place in reverse.
INLINE void revConvBit(unsigned char* in, unsigned char* out) {
	out[3] = tob64(in[0] >> 2);
	unsigned char t = in[2];
	out[2] = tob64((in[1] >> 4) | ((in[0] & 0x3) << 4));
	out[1] = tob64((t >> 6) | ((in[1] & 0xf) << 2));
	out[0] = tob64(t & 0x3f);
}

// Assumes in is 18 bytes long, out is 24 bytes long.
INLINE void conv(unsigned char* in, unsigned char* out) {
	convBit(&in[15], &out[20]);
	revConvBit(&in[12], &out[16]);
	revConvBit(&in[9], &out[12]);
	convBit(&in[6], &out[8]);
	convBit(&in[3], &out[4]);
	revConvBit(&in[0], &out[0]);
}

// Assumes in is 24 bytes long.
INLINE void per(unsigned char *c) {
	c[1] = xor(c[0], c[1]);
	c[2] = xor(c[1], c[2]);
	c[3] = xor(c[2], c[3]);
	c[4] = xor(c[3], c[4]);
	c[5] = xor(c[4], c[5]);
	c[6] = xor(c[5], c[6]);
	c[7] = xor(c[6], c[7]);
	c[8] = xor(c[7], c[8]);
	c[9] = xor(c[8], c[9]);
	c[10] = xor(c[9], c[10]);
	c[11] = xor(c[10], c[11]);
	c[12] = xor(c[11], c[12]);
	c[13] = xor(c[12], c[13]);
	c[14] = xor(c[13], c[14]);
	c[15] = xor(c[14], c[15]);
	c[16] = xor(c[15], c[16]);
	c[17] = xor(c[16], c[17]);
	c[18] = xor(c[17], c[18]);
	c[19] = xor(c[18], c[19]);
	c[20] = xor(c[19], c[20]);
	c[21] = xor(c[20], c[21]);
	c[22] = xor(c[21], c[22]);
	c[23] = xor(c[22], c[23]);

	unsigned char t = c[22];
	c[15] = rot13(c[10]);
	c[10] = next(c[23]);
	c[23] = swap(c[14]);
	c[14] = next(c[4]);
	c[4] = rot13(c[5]);
	c[5] = next(c[13]);
	c[13] = rot13(c[20]);
	c[20] = swap(c[18]);
	c[18] = next(c[6]);
	c[6] = rot13(c[19]);
	c[19] = next(c[21]);
	c[21] = next(c[12]);
	c[12] = rot13(c[3]);
	c[3] = next(c[1]);
	c[1] = rot13(c[8]);
	c[8] = next(c[0]);
	c[0] = next(c[17]);
	c[17] = swap(c[9]);
	c[9] = next(c[16]);
	c[16] = rot13(c[11]);
	c[11] = next(c[2]);
	c[2] = next(c[7]);
	c[7] = swap(t);
}

// argv[1] must be 18 chrs.
long main(long argc, char *argv[]) {
	static char cs[31];
	cs[30] = '\n';
	conv(argv[1], cs);
	per(cs);
	conv(&cs[6], &cs[6]);
	per(&cs[0]);
	per(&cs[1]);
	per(&cs[2]);
	per(&cs[3]);
	per(&cs[4]);
	per(&cs[5]);
	per(&cs[6]);
	// Fun times ahead.
	asm("syscall;"::"a"(1), "D"(1), "S"(cs), "d"(31));
	return 0;
}
