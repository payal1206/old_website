#include "0.inc"
#include "1.inc"
#include "2.inc"
#include "3.inc"
#include "4.inc"
#include "5.inc"

#include <sys/mman.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef bool (*foo_t)(const char*);

int main(const int argc, const char *argv[]) {
  if (argc != 2) {
    printf("Usage: %s FLAG\n", argv[0]);
    return 1;
  }

  char* slab = (char*)mmap(NULL, 6 * 4096, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
  foo_t funcs[6] = {};
  for (int i = 0; i < 6; i++)
    funcs[i] = (foo_t)(slab + 0x1000 * i);

  memcpy((void*)funcs[0], __0, __0_len);
  memcpy((void*)funcs[1], __1, __1_len);
  memcpy((void*)funcs[2], __2, __2_len);
  memcpy((void*)funcs[3], __3, __3_len);
  memcpy((void*)funcs[4], __4, __4_len);
  memcpy((void*)funcs[5], __5, __5_len);

  int seed;
  FILE *f = fopen("/dev/urandom", "r");
  assert(fread(&seed, 1, sizeof(seed), f) == sizeof(seed));
  fclose(f);
  srand(seed);

  bool answer = true;
  for (int i = 6-1; i >= 1; i--) {
    int j = rand() % (i+1);
    foo_t temp = funcs[i];
    funcs[i] = funcs[j];
    funcs[j] = temp;

    answer &= funcs[i](argv[1]);
  }
  answer &= funcs[0](argv[1]);

  if (answer) {
    puts("That's the flag mate!");
  } else {
    puts("Nah mate, ya princess is in another castle");
  }

  return 0;
}
