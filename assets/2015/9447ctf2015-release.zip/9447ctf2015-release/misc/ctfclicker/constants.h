#define THE_FLAG "The Real Flag"

struct buyable {
	char* name;
	int baseCost;
	int income;
};

typedef struct buyable buyable;

buyable buyables[] = {
	(buyable){"Art Money", 5, 4},
	(buyable){"Cheat Engine", 50, 30},
	(buyable){"GNU strings", 1000, 550},
	(buyable){"IDA Pro", 30000, 12000},
	(buyable){"Geohot clone", 1234567, 500000},
	(buyable){THE_FLAG, 224064959, 0}
};

#define TOTAL_TICKS 100
#define BONUS_MONEY_PER_TICK 10

#define NUM_BUYABLES (sizeof(buyables)/sizeof(buyable))
#define STARTING_MONEY 50

#define EXP 1.2
