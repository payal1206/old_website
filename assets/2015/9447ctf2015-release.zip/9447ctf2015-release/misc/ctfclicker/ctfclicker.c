#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <string.h>
#include <unistd.h>
#include <openssl/sha.h>
extern "C" {
#include <libscrypt.h>
}
#include "constants.h"

#define TIMEOUT 40
#define FLAG_PATH "flag.txt"
#define DATA_BYTES 21

int amountOwned[NUM_BUYABLES];
int moneyOwned = STARTING_MONEY;

// TODO check that this doesn't overflow
int costOf(int itemId) {
	return (int)(buyables[itemId].baseCost * pow(EXP, amountOwned[itemId]));
}

void printOwned(void) {
	printf("Money: %d\n", moneyOwned);
	for (int i = 0; i < NUM_BUYABLES; i++) {
		printf("%s:\tOwned: %d\tCost:\t %d\tIncome per item: %d\tTotal income per tick: %d\n", buyables[i].name, amountOwned[i], costOf(i), buyables[i].income, buyables[i].income * amountOwned[i]);
	}
}

void printMoveOptions(void) {
	printf("Moves are:\n");
	for (int i = 0; i < NUM_BUYABLES; i++) {
		printf("b %d\n", i);
	}
	printf("t\n");
}

void tryBuy(int itemId) {
	if (itemId < 0 || itemId >= NUM_BUYABLES) {
		printf("Bad item %d\n", itemId);
		return;
	}
	int cost = costOf(itemId);
	if (cost > moneyOwned) {
		printf("Not enough money (costs %d, have %d)\n", cost, moneyOwned);
		return;
	}

	moneyOwned -= cost;
	amountOwned[itemId]++;
	if (!strcmp(buyables[itemId].name, THE_FLAG)) {
		printf("Good work! Hopefully your machine is running in a well ventilated area\n");
		FILE* f = fopen(FLAG_PATH, "r");
		char flag[50];
		fgets(flag, 50, f);
		fclose(f);
		printf("%s\n", flag);
		exit(0);
	}
}

void doTick(void) {
	for (int i = 0; i < NUM_BUYABLES; i++) {
		moneyOwned += amountOwned[i] * buyables[i].income;
	}
	moneyOwned += BONUS_MONEY_PER_TICK;
}

int unhex(char c) {
	if (isdigit(c)) return c - '0';
	else if (c >= 'a' && c <= 'f') return c - 'a' + 10;
	else if (c >= 'A' && c <= 'F') return c - 'A' + 10;
	else {
		printf("That's bad hex\n");
		exit(1);
	}
}

bool checkHash(unsigned char* hash) {
//#define REQUIRED_PREFIX 0xe0ffffff
#define REQUIRED_PREFIX 0xff
	return (*(unsigned int*)&hash[0] & REQUIRED_PREFIX) == REQUIRED_PREFIX;
}

#define HASH_LENGTH SHA_DIGEST_LENGTH
#define _SCRYPT_N 2048
#define _SCRYPT_R 8
#define _SCRYPT_P 16

int calcHash(unsigned char* data, size_t len, unsigned char* buf) {
#define SALT "NaCl"
	return libscrypt_scrypt(data, len, (uint8_t*) SALT, strlen(SALT), _SCRYPT_N, _SCRYPT_R, _SCRYPT_P, buf, HASH_LENGTH);
/*	if (buf_size != SHA_DIGEST_LENGTH) exit(0);
	SHA1(data, len, buf);*/
}

void getPOW(void) {
	int prefix = rand();

	printf("Don't click too fast, you will get RSI! Let your computer do the work.\n");
	printf("Send a %d byte string (hexed) starting with (hex) ", DATA_BYTES);
	for (int i = 0; i < 4; i++) {
		unsigned char val = ((unsigned char*)&prefix)[i];
		printf("%02x", val);
	}
	printf(" that scrypts with salt \"NaCl\" (quotes for clarity) with parameters N=%d, R=%d, P=%d to a %d byte hash that has a binary representation that starts with 8 ones\n", _SCRYPT_N, _SCRYPT_R, _SCRYPT_P, HASH_LENGTH);
	unsigned char data[DATA_BYTES];

#ifdef HASH_CHECKING
	// This next part is meant to time the hash breaking
	for (int i = 0; i < DATA_BYTES; i++) data[i] = 0;
	memcpy(data, &prefix, 4);
	for (unsigned i = 0; ; i++) {
		*(int*)&data[4] = i;
		unsigned char hash[HASH_LENGTH];
		if (calcHash(data, 21, hash)) {
			printf("Error %d\n", i);
		}
		//printf("BAD ");
		/*for (int j = 0; j < HASH_LENGTH; j++) {
			printf("%x ", hash[j]);
		}
		printf("\n"); */

		if (checkHash(hash)) {
			for (int j = 0; j < HASH_LENGTH; j++) {
				printf("%02x ", hash[j]);
			}
			printf("\n");
			for (int j = 0; j < DATA_BYTES; j++) {
				printf("%02x ", data[j]);
			}

			break;
		}
	}
	//exit(2);
#else
	for (int i = 0; i < DATA_BYTES; i++) {
		char c, b;
		(void)scanf(" %c", &b);
		(void)scanf(" %c", &c);
		data[i] = (unhex(b) << 4) + unhex(c);
	}
#endif

	unsigned char hash[HASH_LENGTH];
	calcHash(data, DATA_BYTES, hash);
	/*for (int i = 0; i < 20; i++) {
	  printf("%x ", hash[i]);
	  }
	  printf("\n");*/

	if (memcmp(&prefix, data, 4)) {
	       printf("Your data didn't begin with the right characters. This is bad. *click*\n");
	       exit(1);
	} else if (!checkHash(hash)) {
		printf("Your hash didn't begin with enough ones. This is bad. *click*\n");
		exit(1);
	}
}

void tryTick(void) {
	getPOW();
	doTick();
}

int main() {
	alarm(TIMEOUT);
	srand(time(NULL) >> 4);
	printf("Welcome to ctfclicker\n");
	printf("You must click your way to victory\n\n");

	for (int tick = 0; tick < TOTAL_TICKS; tick++) {
		while (true) {
			printOwned();
			printMoveOptions();

			char move;
			(void)scanf(" %c", &move);
			if (move == 'b') {
				int itemId;
				(void)scanf(" %d", &itemId);
				tryBuy(itemId);
			} else if (move == 't') {
				tryTick();
				break;
			} else {
				printf("Bad move %c\n", move);
			}
			printf("\n");
		}
	}

	return 0;
}
