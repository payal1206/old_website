<?php

require('../../../include/mellivora.inc.php');

enforce_authentication();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if ($_POST['action'] == 'new') {

        if (!is_valid_id($_POST['user_id'])) {
            message_error('Not a valid id');
        }

        if (!is_valid_ip($_POST['ip'])) {
            message_error('Not a valid IP');
        }

        $id = db_insert(
            'ip_whitelist',
            array(
                'user_id' => $_POST['user_id'],
                'ip' => ip2long($_POST['ip'])
            )
        );

        if ($id) {
            die('OK');
        }
    }

    die('ERROR');
}
