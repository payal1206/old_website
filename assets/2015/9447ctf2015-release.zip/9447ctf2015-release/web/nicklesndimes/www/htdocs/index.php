<?php
require('../include/mellivora.inc.php');

redirect(CONFIG_INDEX_REDIRECT_TO);