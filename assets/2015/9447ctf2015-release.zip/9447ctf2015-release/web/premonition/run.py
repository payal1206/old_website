#!/usr/bin/env python2

from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
from SocketServer import ThreadingMixIn
import threading
import sqlite3
import urllib
from urlparse import urlparse, parse_qs
import json
import os

HOST = '' # Does this need to be changed?
PORT = 9090

index = open('index.html', 'r').read()
indexjs = open('index.js', 'r').read()
indexcss = open('index.css', 'r').read()

class MyHandler(BaseHTTPRequestHandler):
    server_version = "ezw"
    sys_version = ""
    def do_GET(s):
        print s.headers
        if s.path == '/':
            s.send_response(200)
            s.send_header("Content-type", "text/html")
            s.end_headers()
            s.wfile.write(index)
        elif s.path == '/index.css':
            s.send_response(200)
            s.send_header("Content-type", "text/html")
            s.end_headers()
            s.wfile.write(indexcss)
        elif s.path == '/index.js':
            s.send_response(200)
            s.send_header("Content-type", "text/html")
            s.end_headers()
            s.wfile.write(indexjs)
        else:
            s.send_response(400)
            s.end_headers()
            s.wfile.write("File not found")

    def do_POST(s):
        s.send_response(200)
        s.send_header("Content-type", "text/html")
        s.end_headers()

        content_len = int(s.headers.getheader('content-length', 0))
        post_body = s.rfile.read(content_len)

        params = parse_qs(post_body)
#       print params

        equality = ['firstname', 'lastname', 'teacher', 'class']
        inequality = ['score', 'date_birth']
        path = urllib.unquote(s.path[1:])

        if path not in equality and path not in inequality:
            return

        # http://stackoverflow.com/a/28302809
        fd = os.open("example.db", os.O_RDONLY)
        conn = sqlite3.connect('/dev/fd/%d' % fd)
        os.close(fd)
        c = conn.cursor()

        if path in equality and path in params:
            q = c.execute("""select firstname, lastname, score, class from students where %s = ?""" % (path), params[path])
            res = q.fetchall()
        elif path in inequality and path in params:
            ineq = "<"
            if 'ineq' in params and 'sql' not in s.headers['User-agent']:
                ineq = params['ineq'][0]
                ineq = ''.join(ineq.split())
                #ineq = ineq.replace("/", "") #.replace("'", "").replace("\"", "")
            #print """select firstname, lastname, score, class from students where %s %s ?""" % (path, ineq)
            try:
                q = c.execute("""select firstname, lastname, score, class from students where %s %s ?""" % (path, ineq), params[path])
                res = q.fetchall()
            except Exception as e:
                res = {"error": str(e), "user": "sqliteadmin@localhost"}
        else:
            res = ""
#       print res
        s.wfile.write(json.dumps(res) + "\n")
        conn.close()

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    """Handle requests in a separate thread."""

if __name__ == '__main__':
    server = ThreadedHTTPServer((HOST, PORT), MyHandler)
    print 'Starting server, use <Ctrl-C> to stop'
    server.serve_forever()
