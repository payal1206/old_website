#!/usr/bin/env python

import sqlite3
import os
import stat

DB_FILE = "example.db"

try:
	os.remove(DB_FILE)
except:
	pass
conn = sqlite3.connect(DB_FILE)
c = conn.cursor()

# Create table
c.execute('''CREATE TABLE students(
	userid real,
	firstname text,
	lastname text,
	score real,
	teacher real,
	class text,
	date_birth date,
	date_death date
);''')
names = """Xavier Bohm
Mindi Cleaves
Ingeborg Dunham
Layne Agrawal
Kai Nathanson
Catharine Mcnally
Jeromy Duncanson
Lewis Oglesbee
Terri Colombo
Geraldo Penson
Rachael Ackermann
Winford Hendley
Nella Avila
Albertine Walmsley
Tyson Jefferies
Beulah Kaba
Kendra Fettig
Kathie Bieker
Sharon Martelli
Eusebio Champagne
Roni Neuberger
Kristopher Haber
Rubin Puryear
Edwina June
Imogene Burmeister
Jonell Dark
Awilda Oler
Delbert Heminger
Marina Lombardi
Katharyn Veselka"""
def genPerson((i, s)):
	(first, last) = s.split(" ")
	dob = '2005-%02d-%02d' % (len(first), len(last))
	dod = '20%02d-%02d-%02d' % (len(s)*4 + 5, (len(first) * 5) % 11 + 1, (len(last) * 7) % 29 + 1)
	if i % 5 == 0 or i % 4 == 3:
		dod = '2014-10-13'
	return (i, first, last, 100 - len(s) / 2, (len(s) + i) % 4, '5'+"AJDK"[i%4], dob, dod)
values = list(map(genPerson, enumerate(names.split("\n"))))
c.executemany('''INSERT INTO students VALUES(?, ?, ?, ?, ?, ?, ?, ?);''', values)
c.execute('''CREATE TABLE s3ekr17_passwords(
	userid real,
	password text
);''')
entries = list(enumerate("9447{uSerAgenTs_aNd_spaCes_aRe_peasAnt_RacEs}"))
import random
random.shuffle(entries)
c.executemany('''INSERT INTO s3ekr17_passwords VALUES(?, ?);''', entries)
conn.commit()
conn.close()
